<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Props" tilewidth="16" tileheight="16" tilecount="126" columns="18">
 <image source="../../Art/Props.png" width="288" height="112"/>
 <tile id="7">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3.90909" y="15.8182">
    <polygon points="0,0 1,-1.9375 3.8125,-3.875 12.0625,-3.875 12,0.0625"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="8">
  <objectgroup draworder="index" id="2">
   <object id="1" x="12" y="15.9091">
    <polygon points="0,0 -1.0625,-2.0625 -4.9375,-3.8125 -11.9375,-4.0625 -12,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="13">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1.09091" y="15.9091">
    <polygon points="0,0 14,0 14,-10.2102 -0.0909091,-10.1735"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="18">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8.88178e-16" y="14.9091">
    <polygon points="0,0 16,0 16,-8.09091 0.0909091,-8.09091"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="20">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4.18182" y="14.9091">
    <polygon points="0,0 11.7519,0 11.7964,-12.7035 -0.0445147,-12.9432"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="21">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0909091" y="14.7273">
    <polygon points="0,0 11.7519,0 11.7964,-12.7035 -0.0445147,-12.9432"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="23">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0909091" y="16">
    <polygon points="0,0 16,0 15.875,-7.0625 0,-6.9375"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="25">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4.18182" y="0.181818">
    <polygon points="0,0 -1.0625,0.875 -2,3.8125 -3,5.9375 -4.0625,7 -4.125,8.75 -3.1875,9.875 -0.125,9.75 1.8125,8.8125 4.0625,8.6875 5.75,9.75 8,12.9375 8.75,14.6875 9.8125,15.6875 11.9375,15.875 11.9375,-0.125"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="26">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.0909091" y="16">
    <polygon points="0,0 1.875,0.0625 8.0625,-7.0625 11.8125,-6.125 15,-6.125 16,-7 15.9375,-9 12.0625,-16 0,-16"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="28">
  <objectgroup draworder="index" id="2">
   <object id="1" x="5.09091" y="5.18182">
    <polygon points="0,0 1.0625,-1.1875 2.9375,-2.375 10.875,-2.1875 11,9.75 7.9375,9.875 5.0625,8.9375 3,7.875 1,5.8125 -0.0625,3.8125"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="29">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3.55271e-15" y="14.9091">
    <polygon points="0,0 3,0.0625 6.0625,-0.9375 8.125,-2.0625 10.125,-3.9375 11,-6 11.1875,-10 7.125,-11.9375 0.1875,-11.875"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="31">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1.09091" y="0.0454545" width="14" height="15"/>
  </objectgroup>
 </tile>
 <tile id="33">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1" y="16">
    <polygon points="0,0 14,0 14,-12.9091 0.0909091,-13"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
