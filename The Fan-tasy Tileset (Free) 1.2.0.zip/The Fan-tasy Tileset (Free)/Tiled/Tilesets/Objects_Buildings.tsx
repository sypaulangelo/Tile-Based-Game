<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Buildings" tilewidth="175" tileheight="128" tilecount="3" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="89" height="91" source="../../Art/Buildings/House_Hay_Stone_1.png"/>
 </tile>
 <tile id="1">
  <image width="157" height="112" source="../../Art/Buildings/House_Hay_Stone_2.png"/>
 </tile>
 <tile id="2">
  <image width="175" height="128" source="../../Art/Buildings/House_Hay_Stone_3.png"/>
 </tile>
</tileset>
