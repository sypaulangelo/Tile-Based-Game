<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Rocks" tilewidth="16" tileheight="16" tilecount="22" columns="11">
 <image source="../../Art/Rocks.png" width="182" height="32"/>
 <tile id="3">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1.1875" y="12.25">
    <polygon points="0,0 2,1.6875 3.8125,2.6875 10.8125,2.8125 12.8125,1.75 13.75,0.875 13.8125,-2.375 9.6875,-4.1875 1.8125,-4.25 -0.0625,-1.9375"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index" id="2">
   <object id="1" x="3" y="12">
    <polygon points="0,0 2,2.0625 5.875,2.0625 7.875,1.125 8.875,0.125 9.0625,-1.9375 7.0625,-2.8125 2.0625,-2.8125 -0.0625,-1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="11">
  <objectgroup draworder="index" id="2">
   <object id="1" x="2.875" y="3.1875">
    <polygon points="0,0 0,4.625 1,6.9375 2.0625,7.6875 4.125,8.8125 9,8.9375 9.125,9.875 10,10.75 12.125,11.75 13,12 13.125,-3.0625 6.125,-3.1875 2.25,-1.9375"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="12">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.0625" y="15.0625">
    <polygon points="0,0 5.9375,-0.0625 7.9375,-1 10,-3.0625 11.0625,-5.25 12,-7.25 13.0625,-8.25 14.125,-9.125 14,-15 0.0625,-15"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="18">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.0625" y="9.875">
    <polygon points="0,0 4.9375,4.875 9.0625,5.0625 14.0625,-0.1875 14.8125,-2 12.9375,-4.5625 7.625,-5.8125 2.8125,-4.4375 0.75,-3"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="20">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1.875" y="10.875">
    <polygon points="0,0 2.0625,2.0625 11.6875,2.0625 13.0625,3 13.9375,3.125 14.125,-4.8125 3.0625,-4.9375 0.25,-3.75"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="21">
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.1875" y="6.25">
    <polygon points="0,0 4.3125,-0.25 9.1875,0.6875 11.9375,1.8125 14.0625,3.75 14.0625,5.625 13.0625,6.875 6.125,7.8125 0.1875,7.6875"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
